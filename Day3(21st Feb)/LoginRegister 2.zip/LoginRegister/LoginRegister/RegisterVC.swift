//
//  RegisterVC.swift
//  LoginRegister
//
//  Created by MacStudent on 2018-02-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

//class RegisterVC: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
class RegisterVC: UIViewController{
    
    @IBOutlet weak var txtName: UITextField!
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
 
    @IBOutlet weak var txtConfirmPassword: UITextField!
    
    @IBOutlet weak var txtContactNumber: UITextField!
    
    @IBOutlet weak var txtcarNumberPlate: UITextField!
    
    //@IBOutlet weak var dateOfBirth: UIDatePicker!
    
   // @IBOutlet weak var cityPicker: UIPickerView!
    
    
    
    // creating An Array for cityPicker
//
//    var cityList: [String] = ["Vancouver","Ottawa","Toronto","Calgary","Winsdor","Scarborough","Edmonton","Alberta","Montreal","British Columbia","Qubec"]
//    var selectedCityIndex: Int = 0
//
//
//
//    func numberOfComponents(in pickerView: UIPickerView) -> Int{
//        return 1
//
//    }
//
//    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
//        return self.cityList.count
//    }
//
//    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
//        return self.cityList[row]
//    }
    
    override func viewDidLoad(){
        super.viewDidLoad()
        assignbackground()
        
        
        //add data in picker
      ///  self.cityPicker.delegate = self
      //  self.cityPicker.dataSource = self
    }
    
    @objc private func displayValues(){
      //  self.selectedCityIndex = self.cityPicker.selectedRow(inComponent: 0)
        
      //  let allData: String = "\(self.txtName.text!) \n \(self.txtContactNumber.text!) \n \(self.dateOfBirth.date) \n \(self.cityList[selectedCityIndex]) \n \(self.txtEmail.text!)"
        let allData: String = "\(self.txtName.text!) \n  \n \(self.txtEmail.text!) \n \(self.txtPassword.text!) \n \(self.txtContactNumber.text!) \n \(self.txtcarNumberPlate.text!)"
        
        let infoAlert = UIAlertController(title: "Verify", message: allData, preferredStyle: .actionSheet)
        
        infoAlert.addAction(UIAlertAction(title: "Confirm", style: .default , handler: {_ in self.displayWelcomeScreen()}))
         self.present(infoAlert, animated: true)
        
        infoAlert.addAction(UIAlertAction(title: "Cancel", style: .default , handler: nil))
       // self.present(infoAlert, animated: true)
       
        
        
    }
    
    
    // ========== Adding Title To Register Page============
    override func viewWillAppear(_ animated: Bool) {
        self.navigationItem.title = "Register"
        
        let btnSubmit = UIBarButtonItem(title: "Submit", style: .plain, target: self, action: #selector(displayValues))
        
        self.navigationItem.rightBarButtonItem = btnSubmit
    }
    
//    @objc private func displayValues(){
//
//    }
    
    func assignbackground(){
        let background = UIImage(named: "carimage.jpg")
        
        var imageView : UIImageView!
        imageView = UIImageView(frame: view.bounds)
        imageView.contentMode =  UIViewContentMode.scaleAspectFit
        imageView.clipsToBounds = true
        imageView.image = background
        imageView.center = view.center
        view.addSubview(imageView)
        self.view.sendSubview(toBack: imageView)
    }
    
    
    func displayWelcomeScreen(){
        
        let welcomeSB: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        let welcomeVC = welcomeSB.instantiateViewController(withIdentifier: "WelcomeScreen")as! WelcomeVC
        
//        override func viewWillAppear(_ animated: Bool) {
//            self.navigationItem.title = "Welcome"
//        }
        
       // welcomeVC.welcomeTitle = txtName.text!
        
        navigationController?.pushViewController(welcomeVC, animated: true)
    }
    
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
